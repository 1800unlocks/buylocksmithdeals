<?php 
    /*
       Plugin Name: WNW Wassollichessen Customization
       Plugin URI: 
       Description: Allow to customize the website.
       Version: 0.0.1
       Author: Mr. Vikas Sharma
       Author URI: http://webnware.com
	   Text Domain: wnw-wassollichessen-customization
	   Domain Path: /languages
       
   */
define('WNW_WCustomization_PLUGIN_PATH',  dirname(__FILE__));
define('WNW_WCustomization_TEXT_DOMAIN',  'wnw-wassollichessen-customization');
define('WNW_WCustomization_plugin_dir_path',  plugin_dir_path( __FILE__ ));

if ( ! class_exists( 'WNW_WCustomization' ) ) {
	include_once dirname( __FILE__ ) . '/class/class-wnw-w-customization.php';
}


function WNW_WCustomizationInit() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return WNW_WCustomization::instance();
}

// Global for backwards compatibility.
$GLOBALS['WNW_WCustomizationInit'] = WNW_WCustomizationInit();