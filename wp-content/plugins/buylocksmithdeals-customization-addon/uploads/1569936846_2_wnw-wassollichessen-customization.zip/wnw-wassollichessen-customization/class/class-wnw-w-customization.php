<?php
/**
 * WooCommerce setup
 *
 * @package WooCommerce
 * @since   3.2.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Main WooCommerce Class.
 *
 * @class WooCommerce
 */
final class WNW_WCustomization {

    public static $_instance = null;
    public $final_hours=[];
    public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	
	public function __construct() {
            	$this->includes();
		$this->init_hooks();
	}

	private function includes(){
            
        }
        
	private function init_hooks(){
            remove_action( 'geodir_before_search_button', 'geodir_search_form_submit_button', 5000 );
            add_action( 'geodir_before_search_button', array($this,'wnw_wcustomization_geodir_search_form_submit_button'), 5000 );
            remove_action( 'geodir_search_form_inputs', 'geodir_search_form_post_type_input', 10 );
            add_action( 'geodir_search_form_inputs', array($this,'wnw_wcustomization_geodir_search_form_post_type_input'), 11 );
            if(isset($_REQUEST['stype']) && ($_REQUEST['stype'] == 'product' || $_REQUEST['stype'] == 'product_nutrition')) {
            remove_filter('geodir_get_template_part', 'geomkt_geodir_get_template_part', 200, 3);
            add_filter( 'geodir_get_template_part', array($this,'wnw_wcustomization_geomkt_geodir_get_template_part'), 201, 3 );
            
            add_action( 'init', array($this,'onInitHook'));
            add_action( 'geomkt_geodir_search_form_inputs', array($this,'wnw_wcustomization_geodir_search_form_post_type_input'), 11 );
            add_action( 'geomkt_geodir_search_form_inputs', array($this,'wnw_wcustomization_geodir_search_output_to_main_new'), 17 );
            add_action('geomkt_geodir_search_form_inputs', array($this,'wnw_wcustomization_geomkt_geodir_search_form_search_input'), 18);
            
            
            
            
            }
             add_filter( 'woocommerce_general_settings', array($this,'add_plain_text_email_setting') );
             add_filter( 'woocommerce_general_settings', array($this,'add_product_category_type_list_label_setting') );
            add_action( 'wp_footer', array($this,'wnw_wcustomization_start_search'));
            add_action( 'product_cat_add_form_fields', array($this,'product_cat_add_new_meta_field'), 10, 2 );
            add_action( 'product_cat_edit_form_fields', array($this,'product_cat_edit_meta_field'), 10, 2 );
            add_action( 'edited_product_cat', array($this,'save_product_cat_custom_meta'), 10, 2 );
            add_action( 'create_product_cat', array($this,'save_product_cat_custom_meta'), 10, 2 );
            add_action( 'geodir_search_form_post_types', array($this,'geodir_search_form_post_types_add_products'), 11, 1 );
            
            
            add_filter( 'wc_get_template', array($this,'re_wp_override_woo_templates'), 11, 2 );
            if(!class_exists('pi_order_date_time_type')){
                
            }
         //   remove_action( 'woocommerce_checkout_before_customer_details',array('pi_order_date_time_type','adding_field_checkout'));
          //  add_action( 'woocommerce_checkout_before_customer_details',array($this,'wnw_wcustomization_adding_field_checkout'));
            
            
                
            
            remove_action( 'wp_enqueue_scripts', 'pisol_dtt_time_add_scripts' );
            add_action( 'wp_enqueue_scripts', array($this,'pisol_dtt_time_add_scripts') );
            remove_action( 'wp_enqueue_scripts', 'pisol_dtt_date_add_scripts' );
            add_action( 'wp_enqueue_scripts', array($this,'pisol_dtt_date_add_scripts') );
            
//            if(!is_admin()){
//             remove_action( 'admin_enqueue_scripts', array('pisol_dtt_option_time','admin_script_date_time') );
//             add_action( 'admin_enqueue_scripts', array($this,'admin_script_date_time') );
//             
//            }
            //   echo is_admin(); exit;
        }
        
        public function onInitHook(){
            remove_action( 'geomkt_geodir_search_form_inputs', 'geodir_search_form_post_type_input', 10 );
            remove_action( 'geomkt_geodir_search_form_inputs', 'geodir_search_output_to_main_new', 11 );
            remove_action('geomkt_geodir_search_form_inputs', 'geomkt_geodir_search_form_search_input', 15);
            remove_action('geomkt_geodir_search_form_inputs', 'geodir_search_form_near_input_new', 16);
          
             
            
        }

                // Add term page
public function product_cat_add_new_meta_field() { 
	// this will add the custom meta field to the add new term page
     $Cuisine = get_option('product_category_type_list_label_Cuisine');
    $Nutrition = get_option('product_category_type_list_label_Nutrition');
    
	?>
	<div class="form-field">
		
		<fieldset>      
        <legend>What is Product category type?</legend>      
        <input type="radio" name="product_cat_type" value="Cuisine"><?php echo $Cuisine;?><br>      
        <input type="radio" name="product_cat_type" value="Nutrition"><?php echo $Nutrition;?><br>      
        
    </fieldset>      
		
	</div>
<?php
}


function product_cat_edit_meta_field($term) {
 
	// put the term ID into a variable
	$t_id = $term->term_id;
 
	// retrieve the existing value(s) for this meta field. This returns an array
	$term_meta = get_option( "taxonomy_$t_id" );
         
         $term_meta = get_term_meta($t_id, 'product_type');
       
         if($term_meta){
             if(isset($term_meta[0])){
             $term_meta = $term_meta[0];
             }
         }
          $Cuisine = get_option('product_category_type_list_label_Cuisine');
    $Nutrition = get_option('product_category_type_list_label_Nutrition');
    
        ?>
	<tr class="form-field">
	<th scope="row" valign="top"><label for="term_meta[custom_term_meta]"><?php _e( 'Product category type', 'pippin' ); ?></label></th>
		<td>
			
                        <div class="form-field">
		
		<fieldset>      
        
        <input type="radio" name="product_cat_type" <?php if($term_meta=='Cuisine'){ echo 'checked="checked"';} ?> value="Cuisine"><?php echo $Cuisine;?><br>      
        <input type="radio" name="product_cat_type" <?php if($term_meta=='Nutrition'){ echo 'checked="checked"';} ?> value="Nutrition"><?php echo $Nutrition;?><br>      
        
    </fieldset>      
		
	</div>
                        
		</td>
	</tr>
<?php
}


function save_product_cat_custom_meta( $term_id ) {
    
	if ( isset( $_POST['product_cat_type'] ) ) { 
            
		$t_id = $term_id;
		$term_meta = get_option( "taxonomy_$t_id" );
		
		// Save the option array.
		//update_option( "taxonomy_$t_id", $_POST['product_cat_type'] );
                
                update_term_meta ($term_id, 'product_type', $_POST['product_cat_type']);
              
	}
}  



  function geodir_search_form_post_types_add_products($post_type)
  { 
     // return $post_type;
      $product = $post_type->product;
      $gd_place = $post_type->gd_place;
	$myarray = array();
           $Cuisine = get_option('product_category_type_list_label_Cuisine');
    $Nutrition = get_option('product_category_type_list_label_Nutrition');
	$myarray =  array('labels' => array('name' => __($Nutrition, GEOMKT_TEXT_DOMAIN))) ; 
	$product =  array('labels' => array('name' => __($Cuisine, GEOMKT_TEXT_DOMAIN))) ; 
        
       
        
	 $post_type=[];
	$post_type = json_decode(json_encode($post_type), True);
	$post_type['product']= $product;
        $post_type['product_nutrition']= $myarray;
	$post_type['gd_place']= $gd_place;
		
	$post_type = (object) json_decode(json_encode($post_type));
	
	return  $post_type;
	 
  }
        
       function wnw_wcustomization_geodir_search_form_post_type_input() {
	global $geodir_search_post_type,$geodir_search_post_type_hide;
	$post_types     = apply_filters( 'geodir_search_form_post_types', geodir_get_posttypes( 'object' ) );
        
	$curr_post_type = $geodir_search_post_type;

	if ( ! empty( $post_types ) && count( (array) $post_types ) > 1 ) {

		foreach ( $post_types as $post_type => $info ){
			global $wpdb;
                        if($post_type=='product_nutrition'){
                            $post_type = 'product';
                        }
			$has_posts = $wpdb->get_row( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type = %s AND post_status='publish' LIMIT 1", $post_type ) );
			if ( ! $has_posts ) {
				unset($post_types->{$post_type});
			}
		}

		$show_select = true;
		if($geodir_search_post_type_hide == true && !isset( $_REQUEST['stype'] ) ){
			$show_select = false;
		}

		if ( ! empty( $post_types ) && count( (array) $post_types ) > 1 && $show_select) {

			$new_style = geodir_get_option( 'geodir_show_search_old_search_from' ) ? false : true;
			if ( $new_style ) {
				echo "<div class='gd-search-input-wrapper gd-search-field-cpt'>";
			}
			?>
			<select name="stype" class="search_by_post">
				<?php foreach ( $post_types as $post_type => $info ):
					global $wpdb;
					$pt_slug = isset($info->rewrite->slug) ? esc_attr($info->rewrite->slug) : 'places';
                                       
					?>

					<option
						<?php 
                                                $post_type_custom = $post_type;
                                                 if($post_type=='product_nutrition'){ $post_type_custom = 'product'; }
                                                echo ' data-slug="'.$pt_slug.'" ';?>
                                            
						data-label="<?php echo get_post_type_archive_link( $post_type_custom ); ?>"
					        value="<?php echo $post_type; ?>" <?php
					if ( isset( $_REQUEST['stype'] ) ) {
						if ( $post_type == $_REQUEST['stype'] ) {
							echo 'selected="selected"';
						}
					} elseif ( $curr_post_type == $post_type ) {
					//} elseif ( 'product' == $post_type ) {
						echo 'selected="selected"';
					} ?>><?php _e( geodir_utf8_ucfirst( $info->labels->name ), 'geodirectory' ); ?></option>

				<?php endforeach; ?>
			</select>
			<?php
			if ( $new_style ) {
				echo "</div>";
			}
		}else{
			if(! empty( $post_types )){
				$post_types = (array)$post_types;
				if($curr_post_type && isset($post_types[$curr_post_type])){
					$pt_arr = $post_types[$curr_post_type];
					$pt_value = $curr_post_type;
				}else{
					$pt_value = key( $post_types );
					$pt_arr = reset($post_types);
				}

				$pt_slug = isset($pt_arr->rewrite->slug) ? esc_attr($pt_arr->rewrite->slug) : 'places';
				echo '<input type="hidden" name="stype" value="' . esc_attr( $pt_value  ) . '" data-slug="'.$pt_slug.'" />';
			}else{
				echo '<input type="hidden" name="stype" value="gd_place"  data-slug="places"/>';
			}

		}

	}elseif ( ! empty( $post_types ) ) {
		$pt_arr = (array)$post_types;
		$key = key( $pt_arr);
		$pt_arr = $pt_arr[$key];
		$pt_slug = isset($pt_arr->rewrite->slug) ? esc_attr($pt_arr->rewrite->slug) : 'places';
		echo '<input type="hidden" name="stype" value="gd_place" data-slug="'.$pt_slug.'" />';
	}
}

    public  function wnw_wcustomization_geomkt_geodir_get_template_part($template, $slug, $name) {
    
		if($slug == 'listing' && $name == 'filter-form') {
                    
			$template = WNW_WCustomization_PLUGIN_PATH.'/templates/geodirectory/listing-filter-form.php';
		}
                
		return $template;
	}
        
        
    public  function wnw_wcustomization_geodir_search_output_to_main_new(){ 
	  global $geodir_search_main_array, $geodir_search_post_type;
	  //echo $geodir_search_post_type;
	  if(isset($_REQUEST['stype']) && ($_REQUEST['stype'] == 'product' || $_REQUEST['stype'] == 'product_nutrition')) {
              $value = 'Cuisine';
              if($_REQUEST['stype'] == 'product_nutrition'){
                  $value = 'Nutrition';
              }
		  
		  $args = array(
				'order'      => 'ASC',
				'hide_empty' => '',
				'include'    => '',
				'posts_per_page' =>'-1',
                      'meta_query' => array(
    array(
       'key'       => 'product_type',
       'value'     => $value,
       'compare'   => 'LIKE'
    )
),
			);
			$product_categories = get_terms( 'product_cat', $args );  
			echo '<div class="gd-search-input-wrapper gd-search-field-cpt gd-search-field-taxonomy gd-search-field-categories">';
			echo "<select class='cat_select' name='product_cat' onChange='update_result();')>";			
                        ?>
        <option value="" selected="selected">Bitte wählen</option>
        <?php
			foreach( $product_categories as $category ) {
                            
		  	?>
<!--				 <option value="<?php //echo esc_attr( $category->slug ); ?>" <?php //if($category->slug == 'inspire-me'){?>selected="selected"<?php //} ?>><?php //echo esc_html( $category->name ); ?></option>-->
				 <option value="<?php echo esc_attr( $category->slug ); ?>" ><?php echo esc_html( $category->name ); ?></option>
		  <?php
			}
		  echo "</select>";
		  echo '</div>';
	  }
  }

    function wnw_wcustomization_geomkt_geodir_search_form_search_input() { 
		remove_action( 'geodir_search_form_inputs', 'geodir_search_form_search_input', 20 );
		$default_search_for_text = geodir_get_option('search_default_text');
		if(!$default_search_for_text){$default_search_for_text = geodir_get_search_default_text();}
		?>
		<!--div class='gd-search-input-wrapper gd-search-field-search'-->
        <div>
			
			<input class="search_text product_search_text" name="s"
				   value="<?php if ( isset( $_REQUEST['s'] ) && trim( $_REQUEST['s'] ) != '' ) {
					   $search_term = esc_attr( stripslashes_deep( $_REQUEST['s'] ) );
					   echo str_replace(array("%E2%80%99","’"),array("%27","'"),$search_term);
				   } ?>" type="hidden"
				   onkeydown="javascript: if(event.keyCode == 13) geodir_click_search(this);"
				   onClick="this.select();"
				   placeholder="<?php esc_html_e($default_search_for_text,'geodirectory') ?>" 
				   aria-label="<?php esc_html_e($default_search_for_text,'geodirectory') ?>"
				   autocomplete="off"
			/>
			
		</div>
		<?php
	}  
        
       
function wnw_wcustomization_start_search(){
	?>
<script>
    
   function update_result(){
      
       jQuery('.gd-search-bar-style').submit();
   } 
    
    
jQuery(document).ready(function(){
// Or just...

jQuery('.search_by_post')
     .removeAttr('selected');
jQuery(".search_by_post").val("product").trigger('change');
var el = jQuery('.search_by_post');
geodir_load_search_form('product',el);

jQuery(document).on('change','.search_by_post', function(){
     jQuery('.loader_here').show(); 
    
});


  });

    
	</script>
<?php
}

function wnw_wcustomization_geodir_search_form_submit_button() {
 ?>
        
        <div class="loader_here" style="display: none; background-color: #d89e00;font-size: 15px;padding: 6px 12px;margin-top: 5px;height: 100%; color: white;"><i class="fas fa-hourglass fa-spin" aria-hidden="true"></i></div>
        <?php
}




//start Template override.

function re_wp_override_woo_templates( $located, $template_name ) {
    
   if( $template_name == 'emails/new-order-plain.php' ) {
        $located = WNW_WCustomization_plugin_dir_path . 'templates/emails/new-order-plain.php';
    }
//echo $located; exit;
    return $located;   
    
}



// Checkout page work
function get_business_hours_raw($business_hours){
   
    if($business_hours==''){
        return [];
    }
    
   
    $business_hours = explode('],["UTC":', $business_hours);
   
    if(count($business_hours)<2){
        return [];
    }
     $business_hours = $business_hours[0];
     
 
  //  unset($business_hours[(count($business_hours)-1)]);
    $final_time_array=[];
   
    $business_hours = explode('","', $business_hours);
    
   foreach ($business_hours as $day_hours){
    $additiona_hours = [];
    $new_array = [];
       $day_hours = explode(',', $day_hours);
    
    
       if(count($day_hours)>1){
           
            
           foreach($day_hours as $key_final=> $day_hours_fn){
              
               if($key_final>0){
                   $additiona_hours[] = $day_hours_fn;
               }
           }
           
       }
         $day_hours = $day_hours[0];  
       
       
       $day_hours = preg_replace('/[^A-Za-z0-9\. : -]/', '', $day_hours);
      $day_hours =  explode(' ', $day_hours);
   if(count($additiona_hours)<1){ 
       $final_time_array[$day_hours[0]]=$day_hours[1];
   }else{
       $new_array[] = $day_hours[1];
       $final_time_array[$day_hours[0]]= array_merge($new_array,$additiona_hours);
   }
   }
  
     
    
    return $final_time_array;
    
}

function pisol_dtt_time_add_scripts(){
    if (  is_checkout() ) { 
       $day_name =  ["Mo"=>"monday","Tu"=>"tuesday","We"=>"wednesday","Th"=>"thursday","Fr"=>"friday","Sa"=>"saturday","Su"=>"sunday"];
        global $wpdb;
        $total_hours = [];
       foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
            
    $product = $cart_item['data'];
    $product_id = $product->id;
    
    $listing_id = get_post_meta($product_id,'_geomkt_listing',true);
    
     $listing_info = $wpdb->get_row($wpdb->prepare("select business_hours from ".$wpdb->prefix."geodir_gd_place_detail where post_id= %d", array($listing_id)));

if(isset($listing_info->business_hours)){
    
$business_hours =    $this->get_business_hours_raw($listing_info->business_hours);
  
if(!empty($business_hours)){
$total_hours[] = $business_hours;
}
}
    
    
       }
   //print_r($total_hours); exit;
   $unsetDay=[];
   $to_remove = [];
       $final_hours = [];
       if(count($total_hours)){
           foreach($total_hours as $day_hours){
            $unsetDay_sub =    array_keys($day_hours);
           
            
            foreach($day_name as $key_da => $da){
               
                if(!in_array($key_da, $unsetDay_sub)){
                   $unsetDay[]= $da;
                }
            }
        
              // print_r($day_hours); exit;
               if(count($day_hours)){
                   foreach($day_hours as $key=> $day_hr){
                      $key = $day_name[$key];
                       if(is_array($day_hr)){
                          $shortTimeArray =  $this->shortTimeArray($day_hr, $key);
                         if(count($shortTimeArray)>0){
                             
                             $day_hr =$shortTimeArray['open_time'].'-'.$shortTimeArray['close_time'];
                             if(count($shortTimeArray['to_remove'])){
                                //print_r($day_hr); 
                             $to_remove[$key][]=$shortTimeArray['to_remove'];
                             }
                         }else{
                           $day_hr = $day_hr[0];
                         }
                       }
                       $day_hr = explode('-', $day_hr);
                       $day_hr[0] = explode(':', $day_hr[0]);
                           $day_hr[1] = explode(':', $day_hr[1]);
                           $day_hr[0] = $day_hr[0][0];
                           $day_hr[1] = $day_hr[1][0];
                       if(isset($final_hours[$key])){
                           $current_final = $final_hours[$key];
                           
                           
                           if($current_final[0]<$day_hr[0]){
                               $current_final[0] = $day_hr[0];
                           }
                           if($current_final[1]>$day_hr[1]){
                               $current_final[1] = $day_hr[1];
                           }
                           $final_hours[$key] = $current_final;
                          
                       }else{
                           
                           $final_hours[$key] = $day_hr;
                       }
                       
                   }
               }
           }
       }
      
       $unsetDay = array_unique($unsetDay);
       
       if(count($unsetDay)>0){
 foreach ($unsetDay as $un_day){
     if(isset($final_hours[$un_day])){
         unset($final_hours[$un_day]);
     }
 }
       }
       
//       print_r($to_remove);
//  print_r($final_hours); exit;
       if(count($final_hours)){
         
           foreach($final_hours as $key=> $final_hours_inner){
              
               $final_hours[$key]=[date('g:s A', strtotime((string)$final_hours_inner[0].":00")), date('g:s A', strtotime((string)$final_hours_inner[1].":00"))];
               
           }
       }
       $this->final_hours = $final_hours;
      // print_r($final_hours);
//exit;
        $pi_delivery_start_time = get_option('pi_delivery_start_time','9:00 AM');
        $pi_delivery_end_time = get_option('pi_delivery_end_time','9:00 PM');
        $pi_pickup_start_time = get_option('pi_pickup_start_time','9:00 AM');
        $pi_pickup_end_time = get_option('pi_pickup_end_time','9:00 PM');
        $pi_default_type = get_option('pi_default_type','delivery');
        $pi_time_format = get_option('pi_time_format','h:mm p');
        $pi_time_interval = apply_filters('pi_time_interval',15); 
      //          wp_enqueue_script( 'jquery1', 'https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js' );
        wp_enqueue_script( 'jquery-ui-timepicker', plugins_url('assets/js/jquery.timepicker.min.js', __FILE__), array('jquery') );
        wp_enqueue_script( 'moment-ui-timepicker', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js', array('jquery-ui-timepicker') );
        wp_enqueue_style('pi_dtt_timepicker', plugins_url('assets/css/jquery.timepicker.min.css', __FILE__));
   
//        wp_enqueue_script( 'jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js' );
// wp_enqueue_style('pi_dtt_timepicker','https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.min.css');
//        wp_enqueue_script( 'jquery-ui-timepicker', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.min.js', array('jquery') );

        
$final_hours_json = json_encode($final_hours );
$to_remove_json = json_encode($to_remove );
  //print_r($to_remove); exit;
        $delivery_date = ' 
            
            var final_hours = '.$final_hours_json.';
            var to_remove = '.$to_remove_json.';
            //    console.log(to_remove,"to_remove");
               var custom_pickup_start="";
var custom_pickup_end="";
var custom_delivery_start="";
var custom_delivery_end=""; 
        jQuery(function($){
            $("#pi_delivery_time").timepicker({
                interval:'.$pi_time_interval.',
                timeFormat:"'.$pi_time_format.'",
                minTime: "'.$pi_delivery_start_time.'",
                maxTime: "'.$pi_delivery_end_time.'",
                dynamic: false,
                scrollbar: true
            });

           
        });

         var old_date_number="";     
var to_remove_day="";
 var selected="";
   var day = "";
   var day_array="";
    var $ = jQuery;
    var days_remove="";
    
var currentTime="";
var startTime ="";
var endTime ="";
        function pi_set_timing(type, time_values, selected_date){

          selected = ("0" + selected_date.getDate()).slice(-2)+"/"+("0" + (selected_date.getMonth() + 1)).slice(-2)+"/"+selected_date.getFullYear();
          if(typeof pi_current_day_time != "undefined"){
                var today = pi_current_day_time.today_date;
            }else{
                var today = new Date();
                today = ("0" + today.getDate()).slice(-2)+"/"+("0" + (today.getMonth() + 1)).slice(-2)+"/"+today.getFullYear();
            }
             day = selected_date.getUTCDay();
         
            day_array= ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"];
             

custom_pickup_start=time_values.pickup_start;
custom_pickup_end=time_values.pickup_end;
custom_delivery_start=time_values.delivery_start;
custom_delivery_end=time_values.delivery_end;

if(final_hours[day_array[day]]!==undefined && selected!==today){

 custom_pickup_start= final_hours[day_array[day]][0];
 custom_pickup_end= final_hours[day_array[day]][1];
 custom_delivery_start= final_hours[day_array[day]][0];
 custom_delivery_end= final_hours[day_array[day]][1];

}
to_remove_day = day_array[day];
//alert(to_remove_day);

            if(type == "pickup"){ 
              
                $("#pi_delivery_time").timepicker("option","minTime",custom_pickup_start);
                $("#pi_delivery_time").timepicker("option","maxTime",custom_pickup_end);
      // $("#pi_delivery_time").timepicker("option", "disableTimeRanges", [["11:00am","01:00pm"]]);
       //$("#pi_delivery_time").timepicker("remove").timepicker({"disableTimeRanges": [ ["1pm", "2pm"], ["5am", "6:15pm"] ] });
       
       // $("#pi_delivery_time").timepicker("option", { "minTime": "4:00am", "timeFormat": "H:i", "disableTimeRanges": [ ["13:00pm", "14:00pm"], ["5am", "6:15pm"] ] });
                
            }else{
                $("#pi_delivery_time").timepicker("option","minTime",custom_delivery_start);
                $("#pi_delivery_time").timepicker("option","maxTime",custom_delivery_end);
                
            }
  
   selected = ("0" + selected_date.getDate()).slice(-2)+"/"+("0" + (selected_date.getMonth() + 1)).slice(-2)+"/"+selected_date.getFullYear();
  day = selected_date.getUTCDay();
   
     
 


        }
        
   var newObjUiTimepicker = "";
$(document).on("DOMSubtreeModified",".ui-timepicker-viewport",function(){
newObjUiTimepicker = $(this);
if(old_date_number!=to_remove_day){
setTimeout(function(){ 
//console.log(old_date_number,to_remove_day);
old_date_number =  to_remove_day;
 if(to_remove[to_remove_day]!==undefined){   
  days_remove = to_remove[to_remove_day];
 //  console.log(days_remove, "days_remove");

 
 
   //console.log([day_array[day]]);
newObjUiTimepicker.children().each(function(index, value){
var child = $(value).children().html();

if(days_remove.length>0){
for(var day_rm of days_remove){

for(var day_rm_inner of day_rm){
//console.log(day_rm_inner,"day_rm_inner");






currentTime= moment(child, "HH:mm a");
startTime = moment(day_rm_inner[0], "HH:mm a");
endTime = moment(day_rm_inner[1], "HH:mm a");

currentTime.toString(); 
startTime.toString();   
endTime.toString();    

var removeResponse = currentTime.isBetween(startTime, endTime);  // false

if(removeResponse==true){
$(value).children().parent().remove();
}


}
}

}


});
}
},300);
}
});
        

        function change_time_on_date_change(selected_date){ //alert(selected_date); //alert(time_values.pickup_start);
            var $ = jQuery;
            $("#pi_delivery_time").timepicker("close");
            $("#pi_delivery_time").val("");
            var type = $("input[name=\'pi_delivery_type\']:checked").val();
            //console.log(type);
            var day = selected_date.getUTCDay();
            var day_array= ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"];
            
            /* detect today */
            if(typeof pi_current_day_time != "undefined"){
                var today = pi_current_day_time.today_date;
            }else{
                var today = new Date();
                today = ("0" + today.getDate()).slice(-2)+"/"+("0" + (today.getMonth() + 1)).slice(-2)+"/"+today.getFullYear();
            }
            
            selected = ("0" + selected_date.getDate()).slice(-2)+"/"+("0" + (selected_date.getMonth() + 1)).slice(-2)+"/"+selected_date.getFullYear();
            
            if(pi_global_day_time[day_array[day]] != undefined){

                if (today == selected && typeof pi_current_day_time != "undefined") {
                    pi_set_timing(type, pi_current_day_time.today, selected_date);
                }else{
                    pi_set_timing(type, pi_global_day_time[day_array[day]], selected_date);
                }

            }else{

                if (today == selected && typeof pi_current_day_time != "undefined") {
            //    console.log(pi_current_day_time.today);
                    pi_set_timing(type, pi_current_day_time.today, selected_date);
                }else{
              //      console.log(pi_global_day_time["global"]);
                    pi_set_timing(type, pi_global_day_time["global"], selected_date);
                }
            }
        }
        ';
        wp_add_inline_script('jquery-ui-timepicker', $delivery_date);

        /* global time setting */
        if(!pi_dtt_pro_check()){

            $return['global'] = array(
                'delivery_start'=> $pi_delivery_start_time,
                'delivery_end'=> $pi_delivery_end_time,
                'pickup_start'=> $pi_pickup_start_time,
                'pickup_end'=> $pi_pickup_end_time,
            );

            $return = pi_dtt_global_time_correction($return['global']);

            wp_localize_script( 'jquery', 'pi_global_day_time', ($return) ); 
 //$this->pi_free_giveCurrentDateTime($return, $final_hours);

            wp_localize_script( 'jquery', 'pi_current_day_time', ( $this->pi_free_giveCurrentDateTime($return, $final_hours)) );   
        } 
    }
}



function pi_dtt_global_time_correction($value, $final_hours){
    $return = array();


    $delivery_type = get_option('pi_type','Both');
    if($delivery_type == 'Delivery'){
        $value['pickup_start'] = $value['delivery_start'];
        $value['pickup_end'] = $value['delivery_end'];
    }

    if($delivery_type == 'Pickup'){
       $value['delivery_start'] = $value['pickup_start'];
       $value['delivery_end'] = $value['pickup_end'];
    }

    if($delivery_type == 'Both'){
        if($value['pickup_start'] != "" && $value['pickup_end'] != ""){
            if($value['delivery_start'] == "" || $value['delivery_end'] == ""){
                $value['delivery_start'] = '9:00 AM';
                $value['delivery_end'] = '9:00 PM';
            }
        }

        if($value['delivery_start'] != "" && $value['delivery_end'] != ""){
            if($value['pickup_start'] == "" || $value['pickup_end'] == ""){
                $value['pickup_start'] = '9:00 AM';
                $value['pickup_end'] = '9:00 PM';
            }
        }
     }
     
     
     $days = array('sunday','monday','tuesday','wednesday','thursday','friday','saturday');
    $day = date('w');
    
    if(count($final_hours)>0){
if(isset($final_hours[$days[$day]])){
    $time_here = $final_hours[$days[$day]];
  //  print_r($time_here); exit;
        $value['delivery_start'] = $time_here[0];
        $value['delivery_end'] = $time_here[1];
        $value['pickup_start'] = $time_here[0];
        $value['pickup_end'] = $time_here[1];
}

    }
    if($value['delivery_start'] != "" && $value['delivery_end'] != "" && $value['pickup_start'] != "" && $value['pickup_end'] != ""){
        if(strtotime($value['delivery_start']) < strtotime($value['delivery_end']) && strtotime($value['pickup_start']) < strtotime($value['pickup_end'])){
          // print_r($value); exit;
            $return['global']  = $value;
            return $return;
        }
    }

    $return['global'] = array(
        'delivery_start'=> '9:00 AM',
        'delivery_end'=> '9:00 PM',
        'pickup_start'=> '9:00 AM',
        'pickup_end'=> '9:00 PM',
    );

    return $return;

   
}


function pi_free_giveCurrentDateTime($days_timings, $final_hours){
    $days = array('sunday','monday','tuesday','wednesday','thursday','friday','saturday');
    $day = date('w');
    if(isset($days_timings[$days[$day]])){
        $todays_timing = $days_timings[$days[$day]];
    }else{
        $todays_timing = $days_timings['global'];
    }

    $pi_order_preparation_hours = (int)get_option('pi_order_preparation_hours',60);
    
    $current_time = date("h:i A", current_time('timestamp'));
    $start_plug_preparation = strtotime("+ {$pi_order_preparation_hours} minutes", current_time('timestamp'));
    $time = date("h:i A", $start_plug_preparation);

   

    if( (strtotime($todays_timing['delivery_end'], current_time('timestamp')) > $start_plug_preparation) &&  ($start_plug_preparation > strtotime($todays_timing['delivery_start'], current_time('timestamp'))) ){
        $todays_timing['delivery_start'] = date('h:i A', $start_plug_preparation);
    }elseif(strtotime($todays_timing['delivery_end'], current_time('timestamp')) < $start_plug_preparation){
        $todays_timing['delivery_start'] = null;
        $todays_timing['delivery_end'] = null;
    }

    if( (strtotime($todays_timing['pickup_end'], current_time('timestamp')) > $start_plug_preparation) &&  ($start_plug_preparation > strtotime($todays_timing['pickup_start'], current_time('timestamp'))) ){
        $todays_timing['pickup_start'] = date('h:i A', $start_plug_preparation);
    }elseif(strtotime($todays_timing['pickup_end'], current_time('timestamp')) < $start_plug_preparation){
        $todays_timing['pickup_start'] = null;
        $todays_timing['pickup_end'] = null;
    }

    
    
    if(isset($final_hours[$days[$day]])){
        $shop_time = $final_hours[$days[$day]];
        
        $delivery_start = $todays_timing['delivery_start'];
        $delivery_end = $todays_timing['delivery_end'];
        $pickup_start = $todays_timing['pickup_start'];
        $pickup_end = $todays_timing['pickup_end'];
        
        $time="00:05:00"; //5 minutes
if(strtotime($shop_time[0])>strtotime($delivery_start)) {
 $delivery_start = $shop_time[0];
}
if(strtotime($shop_time[0])>strtotime($pickup_start)) {
 $pickup_start = $shop_time[0];
}

if(strtotime($shop_time[1])<=strtotime($delivery_end)) {
 $delivery_end = $shop_time[1];
}
if(strtotime($shop_time[1])<=strtotime($pickup_end)) {
 $pickup_end = $shop_time[1];
}
        $todays_timing['delivery_start'] = $delivery_start;
        $todays_timing['delivery_end'] = $delivery_end;
        $todays_timing['pickup_start'] = $pickup_start;
        $todays_timing['pickup_end'] = $pickup_end;     
    }
   //  print_r($todays_timing); exit;
    /** m/d/y is needed for js  */
    return array('today'=> $todays_timing, 'today_date'=>current_time('d/m/Y'),'today_date_for_js_us'=>current_time('m/d/Y'));
}


function add_plain_text_email_setting( $settings ) {

  $updated_settings = array();

  foreach ( $settings as $section ) {

    // at the bottom of the General Options section
    if ( isset( $section['id'] ) && 'general_options' == $section['id'] &&
       isset( $section['type'] ) && 'sectionend' == $section['type'] ) {

      $updated_settings[] = array(
        'name'     => __( 'Plain Text Email Width', 'wc_plain_text_width' ),
        'desc_tip' => __( 'The starting number for the incrementing portion of the order numbers, unless there is an existing order with a higher number.', 'wc_seq_order_numbers' ),
        'id'       => 'wc_plain_text_width',
        'type'     => 'text',
        'css'      => 'min-width:300px;',
        'std'      => '1',  // WC < 2.0
        'default'  => '1',  // WC >= 2.0
        'desc'     => __( 'default 30', 'wc_plain_text_width' ),
      );
    }

    $updated_settings[] = $section;
  }

  return $updated_settings;
}

function add_product_category_type_list_label_setting( $settings ) {

  $updated_settings = array();

  foreach ( $settings as $section ) {

    // at the bottom of the General Options section
    if ( isset( $section['id'] ) && 'general_options' == $section['id'] &&
       isset( $section['type'] ) && 'sectionend' == $section['type'] ) {

      $updated_settings[] = array(
        'name'     => __( 'Product Category Type label for Cuisine', 'product_category_type_list_label_Cuisine' ),
        'desc_tip' => __( 'Allow the change the Product Category Type label', 'wc_seq_order_numbers' ),
        'id'       => 'product_category_type_list_label_Cuisine',
        'type'     => 'text',
        'css'      => 'min-width:300px;',
        'std'      => '1',  // WC < 2.0
        'default'  => 'Cuisine',  // WC >= 2.0
      );
      $updated_settings[] = array(
        'name'     => __( 'Product Category Type label for Nutrition', 'product_category_type_list_label_Nutrition' ),
        'desc_tip' => __( 'Allow the change the Product Category Type label', 'wc_seq_order_numbers' ),
        'id'       => 'product_category_type_list_label_Nutrition',
        'type'     => 'text',
        'css'      => 'min-width:300px;',
        'std'      => '1',  // WC < 2.0
        'default'  => 'Nutrition',  // WC >= 2.0
      );
    }

    $updated_settings[] = $section;
  }

  return $updated_settings;
}






function pisol_dtt_date_add_scripts(){ 

    global $woocommerce;
    $checkout_url = wc_get_checkout_url();
    $pickup_url = $checkout_url.'?type=pickup';
    $delivery_url = $checkout_url.'?type=delivery';
    if (  is_checkout() ) {

        $pi_delivery_days = get_option('pi_delivery_days','all');
        $pi_pickup_days = get_option('pi_pickup_days','all');
        $pi_preorder_days = abs(get_option('pi_preorder_days', 10));

        $pi_pickup_disable_date = get_option('pisol_dtt_pickup_dd',array());
        $pi_delivery_disabled_date = get_option('pisol_dtt_delivery_dd',array());
        $pi_order_preparation_days  =  get_option('pi_order_preparation_days',0);
        wp_enqueue_script( 'jquery-ui-datepicker' );
        // You need styling for the datepicker. For simplicity I've linked to Google's hosted jQuery UI CSS.
        wp_enqueue_style( 'jquery-ui',  plugins_url('css/jquery-ui.css', __FILE__));

        
         $days = array('sunday','monday','tuesday','wednesday','thursday','friday','saturday');
    $day = date('w');
    $final_hours = $this->final_hours;
    
    if(count($final_hours)>0){
        if(!is_array($pi_delivery_days_arr)){
            $pi_delivery_days_arr=[];
        }
        if(!is_array($pi_pickup_days)){
            $pi_pickup_days=[];
        }
        foreach($final_hours as $key_final=> $days_final){
            if(array_search($key_final,$days )){
                $pi_delivery_days_arr[]=(string)array_search($key_final,$days );
                $pi_pickup_days[]=(string)array_search($key_final,$days );
            }
        }
    }
 //print_r($pi_delivery_days_arr);
 //print_r($pi_pickup_days); exit;
    
        $delivery_date = '
            jQuery(function($){

                $("input[name=\'pi_delivery_type\']").on("change",function(){
                    if($("input[name=\'pi_delivery_type\']:checked").val() == "pickup"){
                        window.location = "'.$pickup_url.'";
                    }else if($("input[name=\'pi_delivery_type\']:checked").val() == "delivery"){
                        window.location = "'.$delivery_url.'";
                    }
                });
               
                $("#pi_delivery_date").datepicker({
                    minDate: '.$pi_order_preparation_days.',
                    maxDate: "'.($pi_preorder_days+$pi_order_preparation_days).'+D",
                    beforeShowDay: function(date){ 
                        var delivery_days = '.json_encode($pi_delivery_days).';
                        var pickup_days = '.json_encode($pi_pickup_days).';
                        
                        var pickup_disable_date =  '.json_encode($pi_pickup_disable_date).';
                        var delivery_disable_date =  '.json_encode( $pi_delivery_disabled_date).';

                        /* Timezone difference handing condition if buyer is one day behind the website, so if the date is less then today date (given by website it will deactivate that date */
                        var today_date_obj = new Date(pi_current_day_time.today_date_for_js_us);
                        if(date < today_date_obj){
                            return [false,""];
                        }

                        /* detect today */
                        if(typeof pi_current_day_time != "undefined"){
                            var today = pi_current_day_time.today_date;
                        }else{
                            var today = new Date();
                            today = ("0" + today.getDate()).slice(-2)+"/"+("0" + (today.getMonth() + 1)).slice(-2)+"/"+today.getFullYear();
                        }
                        focus_date = ("0" + date.getDate()).slice(-2)+"/"+("0" + (date.getMonth() + 1)).slice(-2)+"/"+date.getFullYear();

                        
                        if($("#pi_delivery_type_pickup").is(":checked")){
                            var formated = jQuery.datepicker.formatDate("MM d, yy", date);

                            //This check if date is today if so then if current time is above allowed time range then disable today
                            if (today == focus_date && typeof pi_current_day_time != "undefined") {
                                if(pi_current_day_time.today.pickup_start == null){
                                    return [false,""];
                                }
                            }
                            
                            if(pickup_disable_date != false){
                            if(pickup_disable_date.indexOf(formated) != -1){
                                return [false,""];
                            }
                            }
                            
                            if(pickup_days == "all"){
                                return [true,""];
                            }

                            if(pickup_days.indexOf(date.getDay().toString()) == -1){
                                if(pickup_days != ""){
                                    return [false,""]; 
                                }else{
                                    return [true,""];
                                }
                            }else{
                                return [true,""]; 
                            }

                        }else{

                            var formated = jQuery.datepicker.formatDate("MM d, yy", date);

                            if (today == focus_date && typeof pi_current_day_time != "undefined") {
                                if(pi_current_day_time.today.delivery_start == null){
                                    return [false,""];
                                }
                            }
                            
                            
                            if(delivery_disable_date != false){
                                if(delivery_disable_date.indexOf(formated) != -1){
                                    return [false,""];
                                }
                            }

                            if(delivery_days == "all"){
                                return [true,""];
                            }

                            if(delivery_days.indexOf(date.getDay().toString()) == -1){
                                if(delivery_days != ""){
                                    return [false,""]; 
                                }else{
                                    return [true,""];
                                } 
                            }else{
                                return [true,""]; 
                            }
                        }
                        
                    },
                    onSelect: function(d){

                        if($("#pi_delivery_date").val() == ""){
                            $("#pi_delivery_time").attr(\'disabled\',\'disabled\');
                        }else{
                            $("#pi_delivery_time").removeAttr(\'disabled\');
                        }

                        change_time_on_date_change($(this).datepicker("getDate"));
                    }
                });
                
               
            });
            ';
            wp_add_inline_script('jquery-ui-datepicker', $delivery_date);
    }
}


function shortTimeArray($timeArray, $key){
  
    
    if(count($timeArray)==0){
        return [];
    }
    $open_time = [];
    $close_time = [];
    foreach($timeArray as $timeslotes){
      $timeslotes =  explode('-', $timeslotes);
        
        $open_time[]=$timeslotes[0];
        $close_time[]=$timeslotes[1];
    }
    
    
  
   
   usort($open_time, function($time1, $time2){
    if (strtotime($time1) < strtotime($time2)) 
        return 1; 
    else if (strtotime($time1) > strtotime($time2))  
        return -1; 
    else
        return 0; }); 
   usort($close_time, function($time1, $time2){
    if (strtotime($time1) < strtotime($time2)) 
        return 1; 
    else if (strtotime($time1) > strtotime($time2))  
        return -1; 
    else
        return 0; }); 
$open_time = array_reverse($open_time);
$close_time = array_reverse($close_time);


$to_remove_Hours = [];
$open_time_final = '';
$close_time_final = '';
foreach($open_time as $key=> $open){
    
    //echo $open.'-'.$close_time[$key].'..<br>';
    if($key==0){
    $open_time_final = $open;
    }
    $close_inner = $close_time[$key];
    if(isset($close_time[$key+1])){
        $close_time_final = $close_time[$key+1];
    }
    $open_time_next="00";
     if(isset($open_time[$key+1])){
        $open_time_next = $open_time[$key+1];
    }
    if(strtotime($close_inner)< strtotime($open_time_next)){
      //echo $key; exit;
      $to_remove_Hours[] = [$close_inner,$open_time_next ];
        
    }
    
   // echo $open_inner; exit;
}


return ['open_time'=>$open_time_final, 'close_time'=>$close_time_final, 'to_remove'=>$to_remove_Hours];
}


}
