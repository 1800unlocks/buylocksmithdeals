jQuery(function($){
    
    $("#pi_delivery_start_time, #pi_delivery_end_time, #pi_pickup_start_time, #pi_pickup_end_time").timepicker();

});