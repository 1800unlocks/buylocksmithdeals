jQuery(function($) {
  /* Reset Date and time when type is delivery type is changed */
  $("#pi_delivery_type_pickup, #pi_delivery_type_delivery").on(
    "change",
    function() {
      $("#pi_delivery_time")
        .val("")
        .attr("disabled", "disabled");
      $("#pi_delivery_date").val("");
    }
  );
  /* End */

  /* Load time as disabled, and make it enabled once date is selected */
  /*
    $(document).on('change',"#pi_delivery_date", function(){

        if($("#pi_delivery_date").val() == ""){
            $("#pi_delivery_time").attr('disabled','disabled');
        }else{
            $("#pi_delivery_time").removeAttr('disabled');
        }

    });
    */
  /* End */

  pickup_location();
});

/* Hide pickup address when dileviry type is selected */
function pickup_location() {
  var $ = jQuery;

  var type = $("input[name='pi_delivery_type']:checked").val();
  if (type == "pickup") {
    $("#pisol-pickup-locations").fadeIn();
  } else {
    $("#pisol-pickup-locations").fadeOut();
  }

  $("#pi_delivery_type_pickup, #pi_delivery_type_delivery").on(
    "change",
    function() {
      var value = $(this).val();

      if (value == "pickup") {
        $("#pisol-pickup-locations").fadeIn();
      } else {
        $("#pisol-pickup-locations").fadeOut();
      }
    }
  );
}
