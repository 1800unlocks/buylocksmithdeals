(function($) {
    "use strict";
    window.azh = $.extend({}, window.azh);
    if (!('controls_options' in azh)) {
        azh.controls_options = [];
    }
    azh.controls_options = azh.controls_options.concat([
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Unique ID",
            "control_class": "azh-id",
            "control_type": "azh-id",
            "attribute": "id",
            "restriction": '[href="#{id}"], [data-target="#{id}"], [data-id="#{id}"], [data-for="{id}"]'
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Checkbox-field name",
            "control_class": "azh-name",
            "control_type": "azh-name",
            "selector": "input[type='checkbox'][name]",
            "attribute": "name",
            "unique_wrapper": 'form, [data-section]',
            "unique": '[name="{name}"]',
            "unique_exception": '[name*="[]"]'
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Radio-field name",
            "control_class": "azh-name",
            "control_type": "azh-name",
            "selector": "input[type='radio'][name]",
            "attribute": "name"
        },
        {
            "type": "exists-attribute",
            "menu": "utility",
            "control_text": "Required",
            "control_class": "azh-toggle",
            "control_type": "azh-required",
            "selector": "input[type='checkbox'], input[type='radio']",
            "attribute": "required"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "control_text": "Field name",
            "control_class": "azh-name",
            "control_type": "azh-name",
            "selector": "[name]",
            "attribute": "name",
            "unique_wrapper": 'form, [data-section]',
            "unique": '[name="{name}"]',
            "unique_exception": '[name*="[]"]'
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Hidden field name",
            "control_class": "azh-name",
            "control_type": "azh-name",
            "selector": "[type='hidden'][name]:not([name='form_title'])",
            "attribute": "name",
            "unique_wrapper": 'form, [data-section]',
            "unique": '[name="{name}"]',
            "unique_exception": '[name*="[]"]'
        },
        {
            "type": "dropdown-attribute",
            "selector": "input[type='text'], input[type='color'], input[type='date'], input[type='datetime'], input[type='datetime-local'], input[type='email'], input[type='number'], input[type='tel'], input[type='time'], input[type='url'], input[type='month'], input[type='week']",
            "menu": "context",
            "options": {
                "text": 'text',
                "color": 'color',
                "date": 'date',
                "datetime": 'datetime',
                "datetime-local": 'datetime-local',
                "email": 'email',
                "number": 'number',
                "tel": 'tel',
                "time": 'time',
                "url": 'url',
                "month": 'month',
                "week": 'week'
            },
            "attribute": "type",
            "control_class": "azh-dropdown",
            "control_type": "input-type",
            "control_text": "Input type"
        },
        {
            "type": "exists-attribute",
            "menu": "context",
            "control_text": "Required",
            "control_class": "azh-toggle",
            "control_type": "azh-required",
            "selector": "input:not([type='submit']), textarea, select",
            "attribute": "required"
        },
        {
            "type": "exists-attribute",
            "menu": "utility",
            "control_text": "Checked",
            "control_class": "azh-toggle",
            "control_type": "azh-checked",
            "selector": "input[type='checkbox'], input[type='radio']",
            "attribute": "checked"
        },
        {
            "type": "integer-attribute",
            "menu": "context",
            "attribute": "maxlength",
            "control_class": "azh-maxlength",
            "control_type": "maxlength",
            "selector": "input[maxlength]",
            "control_text": "Maximum input length"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "pattern",
            "control_class": "azh-pattern",
            "control_type": "pattern",
            "selector": "input[pattern]",
            "control_text": "Input regular expression"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "data-mask",
            "control_class": "azh-mask",
            "control_type": "mask",
            "selector": "input[data-mask]",
            "control_text": "Value mask, use: 'a', '9', '*'"
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Checkbox value",
            "control_class": "azh-checkbox-value",
            "control_type": "azh-checkbox-value",
            "selector": "input[type='checkbox']",
            "attribute": "value"
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Radio button value",
            "control_class": "azh-radio-value",
            "control_type": "azh-value",
            "selector": "input[type='radio']",
            "attribute": "value"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "control_text": "Default field value",
            "control_class": "azh-value",
            "control_type": "azh-value",
            "selector": "input[value]",
            "attribute": "value"
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Hidden field value",
            "control_class": "azh-value",
            "control_type": "azh-value",
            "selector": "input[type='hidden'][value]",
            "attribute": "value"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "control_text": "Field placeholder",
            "control_class": "azh-field-placeholder",
            "control_type": "azh-field-placeholder",
            "selector": "[placeholder]",
            "attribute": "placeholder"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "control_text": "Submit button text",
            "control_class": "azh-submit-value",
            "control_type": "azh-submit-value",
            "selector": "input[type='submit']",
            "attribute": "value"
        },
        {
            "type": "font-family",
            "menu": "context",
            "property": "font-family",
            "control_class": "azh-font-family",
            "control_type": "font-family",
            "control_text": "Font family"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "font-size",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "font-size",
            "control_text": "Font size (px)"
        },
        {
            "type": "dropdown-style",
            "menu": "context",
            "property": "font-weight",
            "options": {
                "100": "100",
                "200": "200",
                "300": "300",
                "400": "400",
                "500": "500",
                "600": "600",
                "700": "700",
                "800": "800",
                "900": "900"
            },
            "control_class": "azh-dropdown",
            "control_type": "font-weight",
            "control_text": "Font weight"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "line-height",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "line-height",
            "control_text": "Line height (px)"
        },
        {
            "type": "dropdown-style",
            "menu": "context",
            "property": "text-align",
            "options": {
                "left": "Left",
                "center": "Center",
                "right": "Right"
            },
            "control_class": "azh-dropdown",
            "control_type": "text-align",
            "control_text": "Text align"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "letter-spacing",
            "step": "0.1",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "letter-spacing",
            "control_text": "Letter-spacing (px)"
        },
        {
            "type": "color-style",
            "menu": "context",
            "property": "fill",
            "control_class": "azh-fill",
            "control_type": "fill",
            "control_text": "Fill color"
        },
        {
            "type": "color-style",
            "menu": "context",
            "property": "stroke",
            "control_class": "azh-stroke",
            "control_type": "stroke",
            "control_text": "Stroke color"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "stroke-opacity",
            "min": "0",
            "max": "1",
            "step": "0.01",
            "control_class": "azh-integer",
            "control_type": "stroke-opacity",
            "control_text": "Stroke opacity"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "stroke-width",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "stroke-width",
            "control_text": "Stroke width (px)"
        },
        {
            "type": "color-style",
            "hover": true,
            "menu": "context",
            "property": "fill",
            "control_class": "azh-fill",
            "control_type": "hover-fill",
            "control_text": "Fill color on hover"
        },
        {
            "type": "color-style",
            "hover": true,
            "menu": "context",
            "property": "stroke",
            "control_class": "azh-stroke",
            "control_type": "hover-stroke",
            "control_text": "Stroke color on hover"
        },
        {
            "type": "integer-style",
            "hover": true,
            "menu": "context",
            "property": "stroke-opacity",
            "min": "0",
            "max": "1",
            "step": "0.01",
            "control_class": "azh-integer",
            "control_type": "hover-stroke-opacity",
            "control_text": "Stroke opacity on hover"
        },
        {
            "type": "integer-style",
            "hover": true,
            "menu": "context",
            "property": "stroke-width",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "hover-stroke-width",
            "control_text": "Stroke width (px) on hover"
        },        
        {
            "type": "color-style",
            "menu": "context",
            "property": "color",
            "control_class": "azh-color",
            "control_type": "color",
            "control_text": "Color"
        },
        {
            "type": "color-style",
            "menu": "context",
            "property": "background-color",
            "control_class": "azh-color",
            "control_type": "background-color",
            "control_text": "Background color"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "padding",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "padding",
            "control_text": "Inner space (px)"
        },
        {
            "type": "color-style",
            "menu": "context",
            "property": "border-color",
            "control_class": "azh-color",
            "control_type": "border-color",
            "control_text": "Border color"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "border-width",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "border-width",
            "control_text": "Border width (px)"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "border-radius",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "border-radius",
            "control_text": "Border radius (px)"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "width",
            "control_class": "azh-integer",
            "control_type": "width",
            "control_text": "Width (% or px)"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "height",
            "control_class": "azh-integer",
            "control_type": "height",
            "control_text": "Height (% or px)"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "max-height",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "max-height",
            "control_text": "Max Height (px)"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "margin-top",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "margin-top",
            "control_text": "Margin top (px)"
        },
        {
            "type": "integer-style",
            "menu": "context",
            "property": "margin-bottom",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "margin-bottom",
            "control_text": "Margin bottom (px)"
        },
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "As layer for parent",
            "control_class": "azh-toggle",
            "control_type": "azh-layer",
            "selector": ".az-free-positioning",
            "class": "az-layer"
        },        
        {
            "type": "integer-style",
            "menu": "utility",
            "selector": ".az-free-positioning",
            "property": "z-index",
            "control_class": "azh-integer",
            "control_type": "z-index",
            "control_text": "Layer z-index"
        },
        {
            "type": "integer-style",
            "menu": "utility",
            "selector": ".az-free-positioning > [data-element]",
            "property": "z-index",
            "control_class": "azh-integer",
            "control_type": "z-index",
            "control_text": "Element z-index"
        },
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Container max-width",
            "control_class": "azh-toggle",
            "control_type": "azh-container",
            "selector": ".az-free-positioning > [data-element]",
            "class": "az-container"
        },        
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Full width",
            "control_class": "azh-toggle",
            "control_type": "azh-full-width",
            "selector": ".az-free-positioning > [data-element]",
            "class": "az-full-width"
        },        
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Full height",
            "control_class": "azh-toggle",
            "control_type": "azh-full-height",
            "selector": ".az-free-positioning > [data-element]",
            "class": "az-full-height"
        },                
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Auto rescale",
            "control_class": "azh-toggle",
            "control_type": "azh-auto-rescale",
            "selector": ".az-free-positioning",
            "class": "az-auto-rescale"
        },        
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Full width auto upscale",
            "control_class": "azh-toggle",
            "control_type": "azh-upscale",
            "selector": ".az-free-positioning",
            "class": "az-auto-upscale"
        },        
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Percentage positions",
            "control_class": "azh-toggle",
            "control_type": "azh-percentage",
            "selector": ".az-free-positioning",
            "class": "az-percentage"
        },        
        {
            "type": "exists-class",
            "menu": "utility",
            "control_text": "Full screen height",
            "control_class": "azh-toggle",
            "control_type": "azh-full-height",
            "selector": ".az-free-positioning",
            "class": "az-full-screen-height"
        },        
        {
            "refresh": true,
            "type": "background-image",
            "selector": ".az-free-positioning, .az-background",
            "menu": "utility",
            "control_class": "azh-image",
            "control_type": "background-image",
            "control_text": "Background-image"
        },        
        {
            "refresh": true,
            "type": "color-style",
            "selector": ".az-free-positioning, .az-background",
            "menu": "utility",
            "property": "background-color",
            "control_class": "azh-color",
            "control_type": "background-color",
            "control_text": "Background color"
        },        
        {
            "type": "integer-style",
            "selector": ".az-gmap",
            "menu": "context",
            "property": "height",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "height",
            "control_text": "Google Map height (px)"
        },
        {
            "refresh": true,
            "type": "integer-attribute",
            "selector": ".az-gmap[data-zoom]",
            "menu": "context",
            "attribute": "data-zoom",
            "control_class": "azh-integer",
            "control_type": "zoom",
            "control_text": "Google Map Zoom"
        },
        {
            "refresh": true,
            "type": "image-attribute",
            "selector": ".az-gmap[data-marker]",
            "menu": "context",
            "attribute": "data-marker",
            "control_class": "azh-image",
            "control_type": "marker",
            "control_text": "Google Map location marker image"
        },
        {
            "type": "integer-style",
            "selector": "[data-column-padding][style]",
            "menu": "utility",
            "property": "padding-top",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "padding-top",
            "control_text": "Row padding top (px)"
        },
        {
            "type": "integer-style",
            "selector": "[data-column-padding][style]",
            "menu": "utility",
            "property": "padding-bottom",
            "units": "px",
            "control_class": "azh-integer",
            "control_type": "padding-bottom",
            "control_text": "Row padding bottom (px)"
        },
        {
            "type": "dropdown-attribute",
            "selector": "[data-column-padding]",
            "menu": "utility",
            "options": {
                "0": "0px",
                "5": "5px",
                "10": "10px",
                "15": "15px",
                "20": "20px",
                "25": "25px",
                "30": "30px",
                "40": "40px",
                "50": "50px",
                "60": "60px",
                "70": "70px"
            },
            "attribute": "data-column-padding",
            "control_class": "azh-dropdown",
            "control_type": "column-padding",
            "control_text": "Column padding"
        },
        {
            "refresh": true,
            "type": "background-image",
            "selector": "[data-full-width][style]",
            "menu": "utility",
            "control_class": "azh-image",
            "control_type": "background-image",
            "control_text": "Section background-image"
        },
        {
            "refresh": true,
            "type": "color-style",
            "selector": "[data-full-width][style]",
            "menu": "utility",
            "property": "background-color",
            "control_class": "azh-color",
            "control_type": "background-color",
            "control_text": "Section background color"
        },
        {
            "refresh": true,
            "type": "integer-attribute",
            "selector": "[data-transparency]",
            "menu": "utility",
            "attribute": "data-transparency",
            "control_class": "azh-integer",
            "control_type": "transparency",
            "control_text": "Background color transparency"
        },
        {
            "refresh": true,
            "type": "dropdown-attribute",
            "selector": "[data-background-mode]",
            "menu": "utility",
            "options": {
                "none": "None",
                "cover": "Cover",
                "semi-transparent-color": "Semi-transparent color",
                "contain": "Contain",
                "no-repeat": "No repeat",
                "repeat": "Repeat"
            },
            "attribute": "data-background-mode",
            "control_class": "azh-dropdown",
            "control_type": "background-mode",
            "control_text": "Background mode"
        },
        {
            "refresh": true,
            "type": "toggle-attribute",
            "selector": "[data-parallax]",
            "menu": "utility",
            "attribute": "data-parallax",
            "control_class": "azh-toggle",
            "control_type": "parallax",
            "control_text": "Background parallax"
        },
        {
            "refresh": true,
            "type": "integer-attribute",
            "selector": "[data-parallax-speed]",
            "menu": "utility",
            "attribute": "data-parallax-speed",
            "control_class": "azh-integer",
            "control_type": "parallax-speed",
            "control_text": "Parallax speed"
        },
        {
            "refresh": true,
            "type": "toggle-attribute",
            "selector": "[data-full-width]",
            "menu": "utility",
            "attribute": "data-full-width",
            "control_class": "azh-toggle",
            "control_type": "azh-full-width",
            "control_text": "Full width section"
        },
        {
            "refresh": true,
            "type": "toggle-attribute",
            "selector": "[data-stretch-content]",
            "menu": "utility",
            "attribute": "data-stretch-content",
            "control_class": "azh-toggle",
            "control_type": "azh-stretch-content",
            "control_text": "Stretch section content"
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Backend form identifier",
            "control_class": "azh-form-title",
            "control_type": "azh-form-title",
            "selector": "[type='hidden'][name='form_title']",
            "attribute": "value"
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Confirmation redirect",
            "control_class": "azh-redirect",
            "control_type": "azh-redirect",
            "selector": "form[data-azh-form]",
            "attribute": "data-success-redirect"
        },
        {
            "type": "input-attribute",
            "menu": "utility",
            "control_text": "Confirmation message",
            "control_class": "azh-success",
            "control_type": "azh-success",
            "selector": "form[data-success]",
            "attribute": "data-success"
        },
        {
            "refresh": true,
            "type": "input-attribute",
            "input_type": "text",
            "menu": "utility",
            "control_text": "re-CAPTCHA sitekey",
            "control_class": "azh-sitekey",
            "control_type": "azh-sitekey",
            "selector": ".g-recaptcha",
            "attribute": "data-sitekey"
        },
        {
            "refresh": false,
            "type": "input-attribute",
            "input_type": "text",
            "menu": "utility",
            "control_text": "Video URL",
            "control_class": "azh-video",
            "control_type": "azh-video",
            "selector": "iframe[src]",
            "attribute": "src"
        },
        {
            "type": "post-autocomplete",
            "menu": "context",
            "selector": "[data-fill-from-post]",
            "attribute": "data-fill-from-post",
            "control_class": "azh-dropdown",
            "control_type": "fill-from-post",
            "control_text": "Fill triggered content from post"
        },
        {
            "type": "dropdown-attribute",
            "menu": "context",
            "options": "data-element",
            "attribute": "data-click-trigger",
            "control_class": "azh-dropdown",
            "control_type": "click-trigger",
            "control_text": "Trigger on click"
        },        
        {
            "type": "dropdown-attribute",
            "menu": "context",
            "options": "data-element",
            "attribute": "data-hover-trigger",
            "control_class": "azh-dropdown",
            "control_type": "hover-trigger",
            "control_text": "Trigger on hover"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "data-class-from-post-meta",
            "control_class": "azh-class",
            "control_type": "class-from-post-meta",
            "control_text": "Class from post meta"
        },
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "data-file-meta-field",
            "control_class": "azh-metakey",
            "control_type": "file-meta-field",
            "control_text": "Metakey - value as URL to file"
        },        
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "data-video-meta-field",
            "control_class": "azh-metakey",
            "control_type": "video-meta-field",
            "control_text": "Metakey - value as URL to video"
        },        
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "data-image-meta-field",
            "control_class": "azh-metakey",
            "control_type": "image-meta-field",
            "control_text": "Metakey - value as URL to image"
        },        
        {
            "type": "input-attribute",
            "menu": "context",
            "attribute": "data-meta-field",
            "control_class": "azh-metakey",
            "control_type": "meta-field",
            "control_text": "Metakey - value as text"
        }
    ]);
    if (!('modal_options' in azh)) {
        azh.modal_options = [];
    }
    azh.modal_options = azh.modal_options.concat([
        {
            "menu": 'context',
            "button_text": "Integer range settings",
            "button_class": "azh-integer-range",
            "button_type": "azh-integer-range",
            "title": "Integer range settings",
            "selector": "input[type='range'], input[type='number']",
            "attributes": {
                'value': {
                    "type": "number",
                    "label": "Default value"
                },
                'min': {
                    "type": "number",
                    "label": "Minimum"
                },
                'max': {
                    "type": "number",
                    "label": "Maximum"
                },
                'step': {
                    "type": "number",
                    "label": "Step"
                }
            }
        },
        {
            "refresh": true,
            "button_text": "",
            "button_class": "azh-gmap-location",
            "button_type": "azh-gmap-location",
            "title": "Edit Google Map Location",
            "desc": "Specify the latitude and longitude of the google map",
            "selector": ".az-gmap",
            "attributes": {
                'data-latitude': {
                    "label": "Latitude"
                },
                'data-longitude': {
                    "label": "Longitude"
                }
            }
        }
    ]);
})(window.jQuery);