<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
        <title><?php the_title(); ?></title>
        <?php
        wp_head();
        ?>
    </head>
    <body <?php body_class(); ?>>  
        <div class="az-container">
            <?php while (have_posts()) : the_post(); ?>
                <?php the_content(); ?>
            <?php endwhile; ?>            
        </div>
        <script>
            (function($) {
                $(function() {
                    if ('azh' in $.QueryString && $.QueryString['azh'] == 'customize') {
                        azh.content_wrapper = $('body > div.az-container').first();
                        azh.structure_refresh(azh.content_wrapper);
                        azh.library_init(azh.content_wrapper);
                    }
                });
            })(window.jQuery);
        </script>
        <?php
        wp_footer();
        ?>
    </body>
</html>