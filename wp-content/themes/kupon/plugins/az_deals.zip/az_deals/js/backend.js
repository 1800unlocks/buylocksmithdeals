(function($) {
    $(function() {
    });
})(jQuery);